import pandas as pd, numpy as np, joblib
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
import matplotlib.pyplot as plt

df = pd.read_csv('data/historical_data.csv')
df['TimeIndex'] = range(len(df))

X = df[['TimeIndex']]
y = df['Value']

model = LinearRegression()
model.fit(X, y)

pred = model.predict(X)

print('MAE:', mean_absolute_error(y, pred))
print('R2:', r2_score(y, pred))

joblib.dump(model, 'models/forecast_model.pkl')

future = pd.DataFrame({'TimeIndex': range(len(df), len(df)+30)})
future_pred = model.predict(future)

plt.figure(figsize=(8,4))
plt.plot(df['TimeIndex'], y, label='Actual')
plt.plot(df['TimeIndex'], pred, label='Predicted')
plt.legend()
plt.tight_layout()
plt.savefig('reports/predictions.png')
print('Saved reports/predictions.png')
