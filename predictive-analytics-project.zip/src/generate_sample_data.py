import pandas as pd, numpy as np
np.random.seed(42)
dates = pd.date_range('2020-01-01', periods=500)
trend = np.arange(500) * 0.5 + np.random.normal(0, 10, 500)
pd.DataFrame({'Date': dates, 'Value': trend}).to_csv('data/historical_data.csv', index=False)
print('Historical dataset generated.')
